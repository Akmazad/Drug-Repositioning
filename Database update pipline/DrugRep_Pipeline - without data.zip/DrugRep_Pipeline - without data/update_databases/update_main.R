
source("./update_databases/update_pathway_similarity.R")
source("./update_databases/update_structure_similarity.R")
source("./update_databases/update_target_similarity.R")

update_structure_similarity()
update_pathway_similarity  ()
update_target_similarity   ()

